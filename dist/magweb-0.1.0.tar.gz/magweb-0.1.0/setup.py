from distutils.core import setup
setup(
    name='magweb',
    version='0.1.0',
    description='Python WSGI WEB framework',
    author='wayne',
    author_email='wayne@magedu.com',
    url='https://www.magedu.com',
    packages=['magweb']
)
